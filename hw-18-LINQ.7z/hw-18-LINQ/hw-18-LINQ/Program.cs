﻿namespace LINQ
{
    class Employee
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public int DepId { get; set; }
    }

    class Department
    {
        public int Id { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
    }

    class Program
    {
        static void Main()
        {
            var departments = new[]
            {
                new Department { Id = 1, Country = "Ukraine", City = "Lviv" },
                new Department { Id = 2, Country = "Ukraine", City = "Kyiv" },
                new Department { Id = 3, Country = "France", City = "Paris" },
                new Department { Id = 4, Country = "Ukraine", City = "Odesa" }
            };

            var employees = new[]
            {
                new Employee { Id = 1, FirstName = "Tamara", LastName = "Ivanova", Age = 25, DepId = 2 },
                new Employee { Id = 2, FirstName = "Nikita", LastName = "Larin", Age = 33, DepId = 1 },
                new Employee { Id = 3, FirstName = "Alica", LastName = "Ivanova", Age = 43, DepId = 3 },
                new Employee { Id = 4, FirstName = "Lida", LastName = "Marusyk", Age = 22, DepId = 2 },
                new Employee { Id = 5, FirstName = "Lida", LastName = "Voron", Age = 36, DepId = 4 },
                new Employee { Id = 6, FirstName = "Ivan", LastName = "Kalyta", Age = 22, DepId = 2 },
                new Employee { Id = 7, FirstName = "Nikita", LastName = "Krotov", Age = 27, DepId = 4 }
            };

            Console.WriteLine("1 =============");

            var ukrainianEmployees = employees
                .Join(departments, emp => emp.DepId, dep => dep.Id, (emp, dep) => new { emp, dep })
                .Where(x => x.dep.Country == "Ukraine" && x.dep.City != "Odesa")
                .Select(x => $"{x.emp.FirstName} {x.emp.LastName}");

            foreach (var name in ukrainianEmployees)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine();

            var filteredEmployees = new List<string>();
            foreach (var emp in employees)
            {
                var department = departments.FirstOrDefault(dep => dep.Id == emp.DepId);
                if (department?.Country == "Ukraine" && department.City != "Odesa")
                {
                    filteredEmployees.Add($"{emp.FirstName} {emp.LastName}");
                }
            }

            foreach (var name in filteredEmployees)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("\n2 =============");

            var countries = departments.Select(d => d.Country).Distinct();
            foreach (var country in countries)
            {
                Console.WriteLine(country);
            }

            Console.WriteLine();

            var uniqueCountries = new HashSet<string>();
            foreach (var dep in departments)
            {
                uniqueCountries.Add(dep.Country);
            }

            foreach (var country in uniqueCountries)
            {
                Console.WriteLine(country);
            }

            Console.WriteLine("\n3 =============");

            var topAgedEmployees = employees
                .Where(emp => emp.Age > 25)
                .OrderBy(emp => emp.Id)
                .Take(3);

            foreach (var emp in topAgedEmployees)
            {
                Console.WriteLine($"{emp.FirstName} {emp.LastName}, Age: {emp.Age}");
            }

            Console.WriteLine();

            var topFilteredEmployees = new List<string>();
            int counter = 0;

            foreach (var emp in employees)
            {
                if (emp.Age > 25 && counter < 3)
                {
                    topFilteredEmployees.Add($"{emp.FirstName} {emp.LastName}, Age: {emp.Age}");
                    counter++;
                }
            }

            foreach (var emp in topFilteredEmployees)
            {
                Console.WriteLine(emp);
            }

            Console.WriteLine("\n4 =============");

            var kyivEmployees = employees
                .Join(departments, emp => emp.DepId, dep => dep.Id, (emp, dep) => new { emp, dep })
                .Where(x => x.dep.City == "Kyiv" && x.emp.Age > 23)
                .Select(x => $"{x.emp.FirstName} {x.emp.LastName}, Age: {x.emp.Age}");

            foreach (var emp in kyivEmployees)
            {
                Console.WriteLine(emp);
            }

            Console.WriteLine();

            var selectedKyivEmployees = new List<string>();
            foreach (var emp in employees)
            {
                var department = departments.FirstOrDefault(dep => dep.Id == emp.DepId);
                if (department?.City == "Kyiv" && emp.Age > 23)
                {
                    selectedKyivEmployees.Add($"{emp.FirstName} {emp.LastName}, Age: {emp.Age}");
                }
            }

            foreach (var emp in selectedKyivEmployees)
            {
                Console.WriteLine(emp);
            }
        }
    }
}
